package com.ciclo4.peluqueria.service;





public class RolService {




}
